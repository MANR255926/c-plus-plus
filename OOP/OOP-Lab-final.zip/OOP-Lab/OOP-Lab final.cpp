#include <iostream>
#include <vector>
using namespace std;

class Library
{
protected:
    string name;
    string location;

public:
    Library(string n, string loc) : name(n), location(loc) {}
    virtual void displayInfo()
    {
        cout << "Library Name: " << name << "\nLocation: " << location << endl;
    }
};

class Book : public Library
{
private:
    string title;
    string author;

public:
    Book(string libName, string loc, string t, string a)
        : Library(libName, loc), title(t), author(a) {}

    void displayInfo() override
    {
        Library::displayInfo();
        cout << "Book Title: " << title << "\nAuthor: " << author << endl;
    }
};

class Librarian : public Library
{
private:
    string librarianName;
    int employeeID;

public:
    Librarian(string libName, string loc, string name, int id)
        : Library(libName, loc), librarianName(name), employeeID(id) {}

    void displayInfo() override
    {
        Library::displayInfo();
        cout << "Librarian: " << librarianName << "\nEmployee ID: " << employeeID << endl;
    }
};

int main()
{
    Book b("UMT Library", "UMT", "1984", "Allyan");
    Librarian l("UMT Library", "Joher Town C Block", "Tabish", 101);

    cout << "== Book Info ==\n";
    b.displayInfo();

    cout << "\n== Librarian Info ==\n";
    l.displayInfo();

    return 0;
}