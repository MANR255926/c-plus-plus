
#include <string>

class Person {
public:
    std::string id;
    std::string date_of_birth;
    std::string address;
    std::string name;
    char gender;

    void view_record();
};

class Citizen : public Person {
public:
    std::string national_id;
    std::string marital_status;
    std::string occupation;
    std::string nationality;

    void request_service();
};

class GovUser : public Person {
public:
    int employee_id;
    std::string department;

    void update_record();
    void verify_identity();
};

class IDCard {
public:
    std::string card_number;
    std::string issue_date;
    std::string expiry_date;
    Citizen citizen;

    void generate_id();
};

class TaxRecord {
public:
    std::string record_id;
    Citizen citizen;
    int year;
    float amount_paid;

    void generate_tax_report();
};

class HealthRecord {
public:
    std::string record_id;
    Citizen citizen;
    std::string blood_group;
    std::string known_conditions;

    void update_health_info();
};

