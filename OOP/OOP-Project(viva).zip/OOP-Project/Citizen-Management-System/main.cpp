#include <iostream>
#include "system.h"

void Person::view_record() {
    std::cout << "\nViewing person record of " << name << "\n";
}

void Citizen::request_service() {
    std::cout << name << " is requesting a service...\n";
}

void GovUser::update_record() {
    std::cout << name << " is updating a record...\n";
}

void GovUser::verify_identity() {
    std::cout << name << " is verifying someone's identity...\n";
}

void IDCard::generate_id() {
    std::cout << "Generating ID for " << citizen.name << "\n";
}

void TaxRecord::generate_tax_report() {
    std::cout << "Tax report for " << citizen.name << " for year " << year << "\n";
}

void HealthRecord::update_health_info() {
    std::cout << "Updating health info for " << citizen.name << "\n";
}

int main() {
    Citizen citizen_1;
    citizen_1.name = "Amit";
    citizen_1.id = "CIT001";
    citizen_1.national_id = "IND12345";
    citizen_1.occupation = "Engineer";
    citizen_1.nationality = "Indian";

    GovUser gov_user_1;
    gov_user_1.name = "Meera";
    gov_user_1.employee_id = 101;
    gov_user_1.department = "Citizen Services";

    IDCard id_card;
    id_card.card_number = "ID9901";
    id_card.issue_date = "2020-01-01";
    id_card.expiry_date = "2030-01-01";
    id_card.citizen = citizen_1;

    TaxRecord tax_record;
    tax_record.record_id = "TX101";
    tax_record.year = 2024;
    tax_record.amount_paid = 5550.75f;
    tax_record.citizen = citizen_1;

    HealthRecord health_record;
    health_record.record_id = "HR001";
    health_record.blood_group = "B+";
    health_record.known_conditions = "None";
    health_record.citizen = citizen_1;

    citizen_1.view_record();
    gov_user_1.update_record();
    citizen_1.request_service();
    gov_user_1.verify_identity();
    id_card.generate_id();
    tax_record.generate_tax_report();
    health_record.update_health_info();

    std::cout << "\nSystem operations done!\n";

    return 0;
}

