#include <iostream>
#include "system.h"

Guest::Guest(std::string id, std::string n) {
    guest_id = id;
    name = n;
}

void Guest::request_service(std::string service) {
    std::cout << name << " requested: " << service << std::endl;
}

Room::Room(int number, std::string type) {
    room_number = number;
    room_type = type;
    is_booked = false;
}

bool Room::check_availability() {
    return !is_booked;
}

Reservation::Reservation(std::string id, Guest* g, Room* r) {
    reservation_id = id;
    guest = g;
    room = r;
}

void Reservation::confirm() {
    if (room->check_availability()) {
        room->is_booked = true;
        std::cout << "Reservation confirmed for " << guest->name << std::endl;
    } else {
        std::cout << "Room not available.\n";
    }
}

Invoice::Invoice(std::string id, Reservation* r, double amount) {
    invoice_id = id;
    reservation = r;
    total_amount = amount;
}

void Invoice::generate_invoice() {
    std::cout << "\nInvoice #" << invoice_id << std::endl;
    std::cout << "Guest: " << reservation->guest->name << std::endl;
    std::cout << "Room: " << reservation->room->room_number << std::endl;
    std::cout << "Total: $" << total_amount << std::endl;
}

int main() {
    Guest g1("G001", "Nashit");

    Room r1(101, "Deluxe");

    Reservation res1("R001", &g1, &r1);
    res1.confirm();

    g1.request_service("extra towels or something");

    Invoice inv1("INV101", &res1, 299.99);
    inv1.generate_invoice();

    return 0;
}

