#include <string>

class Room;

class Guest {
public:
    std::string guest_id;
    std::string name;

    Guest(std::string id, std::string n);

    void request_service(std::string service);
};

class Room {
public:
    int room_number;
    std::string room_type;
    bool is_booked;

    Room(int number, std::string type);

    bool check_availability();
};

class Reservation {
public:
    std::string reservation_id;
    Guest* guest;
    Room* room;

    Reservation(std::string id, Guest* g, Room* r);

    void confirm();
};

class Invoice {
public:
    std::string invoice_id;
    Reservation* reservation;
    double total_amount;

    Invoice(std::string id, Reservation* r, double amount);

    void generate_invoice();
};

