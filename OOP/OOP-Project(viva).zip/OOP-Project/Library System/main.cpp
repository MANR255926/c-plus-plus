#include "system.h"

void Account::login() {
    std::cout << name << " logged in." << std::endl;
}

void Member::checkout_book() {
    std::cout << "Book checked out" << std::endl;
}

void Member::reserve_book() {
    std::cout << "Book reserved" << std::endl;
}

void Librarian::add_book() {
    std::cout << "Book added to system" << std::endl;
}

void Librarian::remove_book() {
    std::cout << "Book removed from system" << std::endl;
}

void Manager::manage_staff() {
    std::cout << "Managing staff..." << std::endl;
}

void Manager::view_reports() {
    std::cout << "Viewing reports..." << std::endl;
}

int main() {
    Account acc;
    acc.name = "GenericUser";
    acc.login();

    Member m1;
    m1.name = "Alice";
    m1.id = "M001";
    m1.login();
    m1.checkout_book();
    m1.reserve_book();

    std::cout << std::endl;

    Librarian lib;
    lib.name = "Bob";
    lib.id = "L009";
    lib.login();
    lib.add_book();
    lib.remove_book();

    std::cout << std::endl;

    Manager mgr;
    mgr.name = "Charlie";
    mgr.id = "MG001";
    mgr.login();
    mgr.add_book();
    mgr.remove_book();
    mgr.manage_staff();
    mgr.view_reports();

    std::cout << std::endl;

    Book b1;
    b1.title = "C++ For Beginners";
    b1.author = "Some Author";
    b1.isbn = "123-456";
    b1.available = true;
    std::cout << "Book: " << b1.title << ", Available: " << (b1.available ? "Yes" : "No") << std::endl;

    Fine f;
    f.amount = 25.0;
    f.is_paid = false;
    std::cout << "Fine: $" << f.amount << ", Paid: " << (f.is_paid ? "Yes" : "No") << std::endl;

    return 0;
}

