#include <iostream>
#include <string>

class Account {
public:
    std::string name;
    std::string id;

    void login();
};

class Member : public Account {
public:
    void checkout_book();
    void reserve_book();
};

class Librarian : public Account {
public:
    void add_book();
    void remove_book();
};

class Manager : public Librarian {
public:
    void manage_staff();
    void view_reports();
};

class Book {
public:
    std::string title;
    std::string author;
    std::string isbn;
    bool available;
};

class Loan {
public:
    std::string due_date;
    bool returned;
};

class Reservation {
public:
    std::string date;
    std::string status;
};

class Fine {
public:
    double amount;
    bool is_paid;
};

