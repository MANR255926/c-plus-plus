#include "hospital.h"

// Person methods
void Person::login() {
    cout << name << " logged in\n";
}

void Person::logout() {
    cout << name << " logged out\n";
}

// Patient methods
void Patient::bookAppointment() {
    cout << name << " booked an appointment\n";
}

void Patient::viewPrescription() {
    cout << name << " is checking prescription\n";
}

// Doctor methods
void Doctor::diagnose() {
    cout << name << " is diagnosing someone...\n";
}

void Doctor::prescribe() {
    cout << name << " wrote a prescription\n";
}

// Nurse methods
void Nurse::assistTreatment() {
    cout << name << " is helping in the treatment\n";
}

void Nurse::monitor() {
    cout << name << " is checking up on the patient\n";
}

// Appointment
void Appointment::showAppointment() {
    cout << "\n--- Appointment Details ---\n";
    cout << "Appointment ID: " << appId << "\n";
    cout << "Patient: " << patient.name << "\n";
    cout << "Doctor: " << doctor.name << "\n";
}

// Prescription
void Prescription::printPresc() {
    cout << "\n--- Prescription ---\n";
    cout << "Prescription ID: " << prescId << endl;
    cout << "Patient: " << patient.name << "\n";
    cout << "Doctor: " << doctor.name << "\n";
}

// Room
void Room::showRoom() {
    cout << "\n--- Room Info ---\n";
    cout << "Room No: " << roomNo << "\n";
    cout << "Occupied: " << isOccupied << "\n";
    cout << "VIP Room: " << (isVIP ? "Yes" : "No") << "\n";
}

