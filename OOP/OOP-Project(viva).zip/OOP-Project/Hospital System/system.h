#include <iostream>
#include <string>
using namespace std;

// Base class
class Person {
public:
    string id;
    string contact;
    string name;
    string gender;

    void login();
    void logout();
};

// Patient inherits Person
class Patient : public Person {
public:
    string patientId;
    string illness;

    void bookAppointment();
    void viewPrescription();
};

// Doctor inherits Person
class Doctor : public Person {
public:
    string doctorId;
    string specialization;

    void diagnose();
    void prescribe();
};

// Nurse inherits Person
class Nurse : public Person {
public:
    string nurseId;
    string shift;

    void assistTreatment();
    void monitor();
};

// Connects Patient + Doctor
class Appointment {
public:
    string appId;
    Patient patient;
    Doctor doctor;

    void showAppointment();
};

// Doctor's output
class Prescription {
public:
    string prescId;
    Patient patient;
    Doctor doctor;

    void printPresc();
};

// Room info
class Room {
public:
    int roomNo;
    string isOccupied;
    bool isVIP;

    void showRoom();
};

