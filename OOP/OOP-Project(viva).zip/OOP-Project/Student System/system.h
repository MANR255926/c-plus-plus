#include <iostream>
#include <vector>
#include <string>

class Course;
class Student;
class Teacher;

class Course {
public:
    std::string course_id;
    std::string title;
    std::vector<Student*> students;
    Teacher* teacher;

    Course(std::string id, std::string t);

    void add_student(Student* student);
    void set_teacher(Teacher* t);
};

class Student {
public:
    std::string student_id;
    std::string name;
    std::vector<Course*> courses;

    Student(std::string id, std::string n);

    void enroll(Course* course);
    void print_courses();
};

class Teacher {
public:
    std::string teacher_id;
    std::string name;

    Teacher(std::string id, std::string n);

    void teach(Course* course);
};

class Assignment {
public:
    std::string assignment_id;
    Course* course;
    std::string title;
    std::string due_date;
    std::vector<std::string> student_ids;
    std::vector<std::string> contents;

    Assignment(std::string id, Course* c, std::string t, std::string due);

    void submit(Student* student, std::string content);
    void print_submissions();
};

