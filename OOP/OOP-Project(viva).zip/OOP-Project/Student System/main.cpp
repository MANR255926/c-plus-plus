#include "system.h"

Course::Course(std::string id, std::string t) {
    course_id = id;
    title = t;
    teacher = NULL;
}

void Course::add_student(Student* student) {
    students.push_back(student);
}

void Course::set_teacher(Teacher* t) {
    teacher = t;
}

Student::Student(std::string id, std::string n) {
    student_id = id;
    name = n;
}

void Student::enroll(Course* course) {
    courses.push_back(course);
}

void Student::print_courses() {
    std::cout << name << "'s courses:\n";
    for (int i = 0; i < courses.size(); i++) {
        std::cout << "- " << courses[i]->title << std::endl;
    }
}

Teacher::Teacher(std::string id, std::string n) {
    teacher_id = id;
    name = n;
}

void Teacher::teach(Course* course) {
    course->set_teacher(this);
}

Assignment::Assignment(std::string id, Course* c, std::string t, std::string due) {
    assignment_id = id;
    course = c;
    title = t;
    due_date = due;
}

void Assignment::submit(Student* student, std::string content) {
    for (int i = 0; i < student_ids.size(); i++) {
        if (student_ids[i] == student->student_id) {
            contents[i] = content;
            return;
        }
    }
    student_ids.push_back(student->student_id);
    contents.push_back(content);
}

void Assignment::print_submissions() {
    std::cout << "\nSubmitted assignments:\n";
    for (int i = 0; i < student_ids.size(); i++) {
        std::cout << student_ids[i] << ": " << contents[i] << std::endl;
    }
}

int main() {
    Student s1("S001", "Alice");
    Teacher t1("T101", "Mr. Khan");
    Course c1("CSE101", "Intro to Programming");

    s1.enroll(&c1);
    c1.add_student(&s1);
    t1.teach(&c1);

    Assignment a1("A001", &c1, "Loops HW", "10-07-2025");
    a1.submit(&s1, "hopefully this is right");

    s1.print_courses();
    a1.print_submissions();

    return 0;
}

